setwd("C:/Users/uthay/Desktop/IT24103103")

set.seed(123)
sample_data <- rnorm(25, mean = 45, sd = 2)
print(sample_data)

t_result <- t.test(sample_data, mu = 46, alternative = "less")
print(t_result)

if (t_result$p.value < 0.05) {
  cat("Reject H0: The average baking time is significantly less than 46 minutes.\n")
} else {
  cat("Fail to reject H0: The average baking time is not significantly less than 46 minutes.\n")
}
