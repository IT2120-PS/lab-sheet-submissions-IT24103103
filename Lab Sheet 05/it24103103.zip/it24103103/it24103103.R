setwd("C:\\Users\\it24103103\\Desktop\\it24103103")
delivery_times <- c(34, 54, 47, 29, 39, 61, 20, 40, 57, 36, 38, 44, 59, 38, 40, 40, 67, 66, 55, 48, 52, 59, 35, 56, 32, 38, 54, 30, 43, 36, 42, 20, 27, 38, 54, 43, 45, 51, 36, 47)
Delivery_Times <- data.frame(Delivery_Time = delivery_times)
head(Delivery_Times)


hist(Delivery_Times$Delivery_Time, 
     breaks = seq(20, 70, by = 5), 
     col = "lightblue", 
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)", 
     ylab = "Frequency", 
     right = TRUE)

# Create the histogram data without plotting
hist_data <- hist(Delivery_Times$Delivery_Time, 
                  breaks = seq(20, 70, by = 5), 
                  plot = FALSE)

hist_data <- hist(Delivery_Times$Delivery_Time, 
                  breaks = seq(20, 70, by = 5), 
                  plot = FALSE)

cum_freq <- cumsum(hist_data$counts)

plot(hist_data$mids, cum_freq, type = "o", 
     col = "blue", pch = 16, lwd = 2, 
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency")

